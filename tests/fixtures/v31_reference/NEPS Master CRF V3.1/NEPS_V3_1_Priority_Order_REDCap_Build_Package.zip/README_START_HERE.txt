NEPS GENERIC MASTER CRF V3.1 PRIORITY ORDER

All 188 original participant questions retained, no wording/coding/ID changes.

Screening: P01–P09, Q001–Q073 (73)
Cohort interest: P10, Q074–Q078 (5)
Extended: P11–P21, Q079–Q152 (74)
Detailed: P22–P26, Q153–Q188 (36)

12 imported fields and 22 downstream derived/cohort outputs are not participant questions.
26 REDCap page units in five respondent-facing surveys.

READ: NEPS_V3_1_REDCap_Page_by_Page_Build_Specification.docx
TRACE: NEPS_V3_1_Ordered_Item_to_Analysis_Map.csv
PLAN: NEPS_V3_1_REDCap_Page_Plan.csv

Source: /mnt/data/NEPS_Generic_Master_CRF_V3_1_Package/NEPS_V3_1_Item_to_Construct_and_Analysis_Map.csv

These are proposed REDCap form/page names, not live verified project metadata.

